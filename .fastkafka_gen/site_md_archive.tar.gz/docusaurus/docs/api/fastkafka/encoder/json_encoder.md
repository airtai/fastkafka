### json_encoder {#fastkafka.encoder.json_encoder}

<a href="https://github.com/airtai/fastkafka/blob/main/fastkafka/_components/encoder/json.py#L28-L38" class="link-to-source" target="_blank">View source</a>

```py
json_encoder(
    msg
)
```

Encoder to encode pydantic instances to json string

**Parameters**:

|  Name | Type | Description | Default |
|---|---|---|---|
| `msg` | `BaseModel` | An instance of pydantic basemodel | *required* |

**Returns**:

|  Type | Description |
|---|---|
| `bytes` | Json string in bytes which is encoded from pydantic basemodel |

